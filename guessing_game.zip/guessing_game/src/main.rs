// input/output library used to obtain user input and print the result as output
use std::io;
// random number generator
use rand::Rng;
// has the variants less, greater, and equal
use std::cmp::Ordering;

// fn = function
fn main() {
    // prints string to the screen
    println!("Guess the number");

    // random number generation
    let secret_number = rand::thread_rng().gen_range(1..=100);
    // prints string with variable
    //println!("The secret number is: {secret_number}");

    loop {
        // prints string
        println!("Please input your guess");

        // variable that stores user input (this line has cerated a mutable variable that is currently bound to a new, empty instance of a String)
        // let: creates the variable
        // mut: makes variable mutable
        let mut guess = String::new();

        // receiving user input
        // calling the stdin function from the io module to allow us to handle user input
        io::stdin()
            // calls the read_line method on the standard input handle to get input from the user
            // passing &mut guess as the argument to read_line to tell it what string to store the user input in
            .read_line(&mut guess)
            // else statement
            // expect causes the program to crash and display the message that was passed as an argument to it
            // if expect isn't called, the program will still compile but you will get a warning
            .expect("Failed to read line");

        // shadows (reuses) the previous value of guess and handles errors
        let guess: u32 = match guess.trim().parse() {
            Ok(num) => num,
            Err(_) => continue,
        };

        // prints user input
        println!("You guessed: {guess}");

        // compares user input to secret number
        match guess.cmp(&secret_number) {
            // if user input is smaller than secret number
            Ordering::Less => println!("Too small!"),
            // if user input is greater than secret number
            Ordering::Greater => println!("Too big!"),
            // if user input is equal to secret number
            Ordering::Equal => {
                println!("You win!");
                break;
            }
        }
    }
}
